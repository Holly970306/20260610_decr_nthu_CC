#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
引用驗證報告轉 Google Sheets 格式 — Citation Report to Sheets

將 verify_citations.py 產出的 JSON 報告轉換為可匯入 Google Sheets 的 CSV 格式，
欄位對應原始 Google Apps Script 工具的格式。

作者：阿亮老師・3A科技研究社
版本：1.0.0

使用方式：
    python citation_to_sheets.py --input report.json --output sheets_import.csv
    python citation_to_sheets.py --input report.json  # 預設輸出 report_sheets.csv

參考 Google Sheets 模板：
    https://docs.google.com/spreadsheets/d/1GYWTiRzWPzEot7NSmCaMcARDBIpB2AAjY3RBZM25RKQ/edit?gid=0#gid=0
"""

import argparse
import csv
import json
import os
import sys


# Google Sheets 欄位名稱（對應原始 GAS 工具格式）
SHEET_COLUMNS = [
    "文章標題",
    "狀態",
    "配對標題",
    "相似度",
    "年份",
    "作者",
    "期刊名稱",
    "卷數",
    "頁碼",
    "出版類型",
    "來源網址",
    "APA 引用格式",
]


def load_report(filepath):
    """載入 verify_citations.py 產出的 JSON 報告。"""
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 支援兩種格式：帶 metadata 的報告或純結果陣列
    if isinstance(data, dict) and "results" in data:
        return data["results"]
    elif isinstance(data, list):
        return data
    else:
        raise ValueError("無法辨識的 JSON 報告格式")


def convert_to_sheets_csv(results, output_path):
    """
    將驗證結果轉換為 Google Sheets 匯入格式的 CSV。
    使用 UTF-8 BOM 確保 Google Sheets 和 Excel 正確顯示中文。
    """
    with open(output_path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(SHEET_COLUMNS)

        for r in results:
            writer.writerow([
                r.get("query_title", ""),
                r.get("status", ""),
                r.get("matched_title", ""),
                r.get("similarity", 0),
                r.get("year", "") if r.get("year") else "",
                r.get("authors", ""),
                r.get("venue", ""),
                r.get("volume", ""),
                r.get("pages", ""),
                r.get("pub_type", ""),
                r.get("url", ""),
                r.get("apa_citation", ""),
            ])

    print(f"已輸出 Google Sheets 匯入用 CSV：{output_path}")
    print(f"共 {len(results)} 筆資料")
    print()
    print("匯入方式：")
    print("  1. 開啟 Google Sheets")
    print("  2. 檔案 → 匯入 → 上傳 → 選擇此 CSV")
    print("  3. 選擇「取代目前工作表」或「插入新工作表」")
    print("  4. 分隔符號選擇「逗號」")
    print()
    print("參考模板：")
    print("  https://docs.google.com/spreadsheets/d/"
          "1GYWTiRzWPzEot7NSmCaMcARDBIpB2AAjY3RBZM25RKQ/edit?gid=0#gid=0")


def print_summary(results):
    """印出摘要統計。"""
    total = len(results)
    verified = sum(1 for r in results if r.get("status") == "已驗證")
    possible = sum(1 for r in results if r.get("status") == "可能匹配")
    not_matched = total - verified - possible

    print()
    print("=" * 50)
    print("驗證結果摘要")
    print("=" * 50)
    print(f"  總計：{total} 筆")
    print(f"  已驗證：{verified} 筆")
    print(f"  可能匹配：{possible} 筆")
    print(f"  不匹配/查無結果：{not_matched} 筆")
    print(f"  驗證率：{verified / total * 100:.1f}%" if total > 0 else "  驗證率：N/A")
    print("=" * 50)
    print()


def main():
    parser = argparse.ArgumentParser(
        description="將引用驗證 JSON 報告轉換為 Google Sheets 匯入用 CSV",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
範例：
  python citation_to_sheets.py --input report.json
  python citation_to_sheets.py --input report.json --output my_sheets.csv

參考 Google Sheets 模板：
  https://docs.google.com/spreadsheets/d/1GYWTiRzWPzEot7NSmCaMcARDBIpB2AAjY3RBZM25RKQ/edit?gid=0#gid=0

作者：阿亮老師・3A科技研究社
        """
    )
    parser.add_argument(
        "--input", "-i", required=True,
        help="verify_citations.py 產出的 JSON 報告路徑"
    )
    parser.add_argument(
        "--output", "-o", default=None,
        help="輸出 CSV 檔案路徑（預設：<input>_sheets.csv）"
    )

    args = parser.parse_args()

    # 決定輸出路徑
    if args.output:
        output_path = args.output
    else:
        base = os.path.splitext(args.input)[0]
        output_path = f"{base}_sheets.csv"

    # 載入報告
    print(f"載入報告：{args.input}")
    try:
        results = load_report(args.input)
    except Exception as e:
        print(f"錯誤：無法載入報告 — {e}", file=sys.stderr)
        sys.exit(1)

    if not results:
        print("警告：報告中沒有驗證結果。", file=sys.stderr)
        sys.exit(0)

    # 印出摘要
    print_summary(results)

    # 轉換並輸出
    convert_to_sheets_csv(results, output_path)


if __name__ == "__main__":
    main()
