#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
引用驗證工具 — Citation Verification Tool
透過 Crossref API 驗證學術引用的正確性與完整性。

作者：阿亮老師・3A科技研究社
版本：1.0.0

使用方式：
    python verify_citations.py --input references.txt --output report.md --threshold 0.6
    python verify_citations.py --input references.json --output report.json --threshold 0.7

輸入格式：
    - .txt：每行一個論文標題
    - .json：JSON 陣列，每個元素含 "title" 欄位

輸出格式：
    - json：完整 JSON 驗證報告
    - csv：CSV 表格（可匯入 Google Sheets）
    - md：Markdown 表格
"""

import argparse
import csv
import io
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime


# ============================================================
# 相似度計算（移植自 Google Apps Script）
# ============================================================

def normalize_text(text):
    """正規化文字：轉小寫、移除標點、合併空白。"""
    if not text:
        return ""
    text = text.lower().strip()
    text = re.sub(r'[^\w\s]', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def tokenize(text):
    """將文字切分為詞彙集合。"""
    return set(normalize_text(text).split())


def jaccard_similarity(text_a, text_b):
    """計算 Jaccard 相似度。"""
    set_a = tokenize(text_a)
    set_b = tokenize(text_b)
    if not set_a or not set_b:
        return 0.0
    intersection = set_a & set_b
    union = set_a | set_b
    return len(intersection) / len(union) if union else 0.0


def substring_bonus(query, candidate):
    """子字串獎勵：若正規化後的查詢是候選標題的子字串（或反之），給予額外加分。"""
    norm_q = normalize_text(query)
    norm_c = normalize_text(candidate)
    if not norm_q or not norm_c:
        return 0.0
    if norm_q in norm_c or norm_c in norm_q:
        shorter = min(len(norm_q), len(norm_c))
        longer = max(len(norm_q), len(norm_c))
        return 0.3 * (shorter / longer) if longer > 0 else 0.0
    return 0.0


def calculate_similarity(query, candidate):
    """計算綜合相似度 = Jaccard + 子字串獎勵（上限 1.0）。"""
    jac = jaccard_similarity(query, candidate)
    bonus = substring_bonus(query, candidate)
    return min(jac + bonus, 1.0)


# ============================================================
# 出版類型評分（移植自 Google Apps Script）
# ============================================================

TYPE_SCORES = {
    "journal-article": 10,
    "proceedings-article": 8,
    "book-chapter": 7,
    "book": 6,
    "dissertation": 5,
    "posted-content": 3,   # preprint
    "dataset": 2,
    "report": 4,
    "monograph": 5,
}


def get_type_score(pub_type):
    """取得出版類型分數，預設為 1。"""
    return TYPE_SCORES.get(pub_type, 1)


# ============================================================
# Crossref API 查詢
# ============================================================

CROSSREF_API = "https://api.crossref.org/works"
USER_AGENT = "CitationVerifier/1.0 (mailto:research@example.com)"
REQUEST_INTERVAL = 1.0  # 秒，速率限制


def search_crossref(title, rows=5):
    """
    透過 Crossref API 搜尋論文標題。
    回傳候選項目清單。
    """
    params = urllib.parse.urlencode({
        "query.bibliographic": title,
        "rows": rows,
        "select": "DOI,title,author,published-print,published-online,"
                  "container-title,volume,page,type,URL,score"
    })
    url = f"{CROSSREF_API}?{params}"

    req = urllib.request.Request(url)
    req.add_header("User-Agent", USER_AGENT)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("message", {}).get("items", [])
    except (urllib.error.URLError, urllib.error.HTTPError, Exception) as e:
        print(f"  [警告] Crossref API 查詢失敗：{e}", file=sys.stderr)
        return []


def get_apa_citation(doi):
    """
    透過 DOI 取得 APA 格式引用。
    使用 content negotiation：Accept: text/bibliography; style=apa
    """
    url = f"https://doi.org/{doi}"
    req = urllib.request.Request(url)
    req.add_header("Accept", "text/bibliography; style=apa")
    req.add_header("User-Agent", USER_AGENT)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read().decode("utf-8").strip()
    except Exception as e:
        print(f"  [警告] 取得 APA 引用失敗（DOI: {doi}）：{e}", file=sys.stderr)
        return ""


# ============================================================
# 候選項目解析與排序
# ============================================================

def extract_year(item):
    """從 Crossref 項目中提取出版年份。"""
    for field in ("published-print", "published-online"):
        date_parts = item.get(field, {}).get("date-parts", [[]])
        if date_parts and date_parts[0] and date_parts[0][0]:
            return date_parts[0][0]
    return None


def extract_authors(item):
    """從 Crossref 項目中提取作者清單，格式：姓, 名."""
    authors = item.get("author", [])
    parts = []
    for a in authors:
        family = a.get("family", "")
        given = a.get("given", "")
        if family and given:
            parts.append(f"{family}, {given}")
        elif family:
            parts.append(family)
    return "; ".join(parts) if parts else ""


def extract_venue(item):
    """從 Crossref 項目中提取期刊/會議名稱。"""
    ct = item.get("container-title", [])
    return ct[0] if ct else ""


def extract_title(item):
    """從 Crossref 項目中提取標題。"""
    titles = item.get("title", [])
    return titles[0] if titles else ""


def rank_candidates(query_title, candidates):
    """
    對候選項目排序。
    排序邏輯（與 GAS 相同）：
      1. 相似度（降序）
      2. 出版類型分數（降序）
      3. 出版年份（降序，較新優先）
    """
    scored = []
    for item in candidates:
        candidate_title = extract_title(item)
        sim = calculate_similarity(query_title, candidate_title)
        pub_type = item.get("type", "")
        type_score = get_type_score(pub_type)
        year = extract_year(item) or 0

        scored.append({
            "item": item,
            "similarity": sim,
            "type_score": type_score,
            "year": year,
            "candidate_title": candidate_title,
        })

    scored.sort(key=lambda x: (x["similarity"], x["type_score"], x["year"]),
                reverse=True)
    return scored


# ============================================================
# 驗證流程
# ============================================================

def verify_single(title, threshold=0.6):
    """
    驗證單一論文標題。
    回傳驗證結果字典。
    """
    result = {
        "query_title": title,
        "status": "未找到",
        "matched_title": "",
        "similarity": 0.0,
        "year": None,
        "authors": "",
        "venue": "",
        "volume": "",
        "pages": "",
        "pub_type": "",
        "url": "",
        "doi": "",
        "google_scholar_link": "",
        "apa_citation": "",
    }

    candidates = search_crossref(title)
    if not candidates:
        result["status"] = "查無結果"
        return result

    ranked = rank_candidates(title, candidates)
    if not ranked:
        result["status"] = "查無結果"
        return result

    best = ranked[0]
    item = best["item"]
    sim = best["similarity"]

    result["matched_title"] = best["candidate_title"]
    result["similarity"] = round(sim, 4)
    result["year"] = best["year"] if best["year"] else None
    result["authors"] = extract_authors(item)
    result["venue"] = extract_venue(item)
    result["volume"] = item.get("volume", "")
    result["pages"] = item.get("page", "")
    result["pub_type"] = item.get("type", "")
    result["url"] = item.get("URL", "")
    result["doi"] = item.get("DOI", "")

    # Google Scholar 連結
    scholar_query = urllib.parse.quote(title)
    result["google_scholar_link"] = (
        f"https://scholar.google.com/scholar?q={scholar_query}"
    )

    # 判定狀態
    if sim >= threshold:
        result["status"] = "已驗證"
    elif sim >= threshold * 0.7:
        result["status"] = "可能匹配"
    else:
        result["status"] = "不匹配"

    # 取得 APA 引用
    if result["doi"] and sim >= threshold * 0.7:
        time.sleep(REQUEST_INTERVAL)
        result["apa_citation"] = get_apa_citation(result["doi"])

    return result


def verify_batch(titles, threshold=0.6, resume_file=None):
    """
    批次驗證論文標題。
    支援斷點續跑：讀取已有結果，跳過已查核項目，每筆即時寫入。
    """
    # 載入已有結果（續跑模式）
    existing_results = []
    verified_titles = set()
    if resume_file and os.path.isfile(resume_file):
        try:
            with open(resume_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                existing_results = data.get("results", [])
                verified_titles = {r["query_title"].strip().lower() for r in existing_results}
                print(f"  續跑模式：已有 {len(existing_results)} 筆結果，跳過已查核項目")
        except Exception:
            pass

    results = list(existing_results)
    total = len(titles)
    skipped = 0

    for i, title in enumerate(titles, 1):
        title = title.strip()
        if not title:
            continue

        # 跳過已查核
        if title.lower() in verified_titles:
            skipped += 1
            print(f"  [{i}/{total}] 已查核，跳過：{title[:50]}...")
            continue

        print(f"  [{i}/{total}] 驗證中：{title[:60]}{'...' if len(title) > 60 else ''}")
        result = verify_single(title, threshold)
        results.append(result)

        # 每筆即時寫入（防止中途斷線遺失）
        if resume_file:
            _save_progress(results, resume_file)

        # 速率限制
        if i < total:
            time.sleep(REQUEST_INTERVAL)

    if skipped > 0:
        print(f"\n  共跳過 {skipped} 筆已查核項目")

    return results


def _save_progress(results, filepath):
    """即時儲存進度到 JSON 檔案。"""
    report = {
        "generated_at": datetime.now().isoformat(),
        "total": len(results),
        "verified": sum(1 for r in results if r["status"] == "已驗證"),
        "results": results,
    }
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)


# ============================================================
# 輸入解析
# ============================================================

def load_input(filepath):
    """
    載入輸入檔案。
    支援 .txt（每行一標題）和 .json（陣列或含 title 欄位的物件陣列）。
    """
    ext = os.path.splitext(filepath)[1].lower()

    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    if ext == ".json":
        data = json.loads(content)
        if isinstance(data, list):
            titles = []
            for item in data:
                if isinstance(item, str):
                    titles.append(item)
                elif isinstance(item, dict) and "title" in item:
                    titles.append(item["title"])
            return titles
        else:
            raise ValueError("JSON 檔案必須是陣列格式")
    else:
        # 預設當作 .txt 處理
        return [line.strip() for line in content.splitlines() if line.strip()]


# ============================================================
# 輸出格式化
# ============================================================

def output_json(results, filepath=None):
    """輸出 JSON 格式報告。"""
    report = {
        "generated_at": datetime.now().isoformat(),
        "total": len(results),
        "verified": sum(1 for r in results if r["status"] == "已驗證"),
        "possible": sum(1 for r in results if r["status"] == "可能匹配"),
        "not_matched": sum(1 for r in results
                          if r["status"] in ("不匹配", "查無結果", "未找到")),
        "results": results,
    }
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if filepath:
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"\n已輸出 JSON 報告：{filepath}")
    return text


def output_csv(results, filepath=None):
    """輸出 CSV 格式報告。"""
    columns = [
        "文章標題", "狀態", "配對標題", "相似度", "年份",
        "作者", "期刊名稱", "卷數", "頁碼", "出版類型",
        "來源網址", "Google Scholar", "APA 引用格式"
    ]

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(columns)

    for r in results:
        writer.writerow([
            r["query_title"],
            r["status"],
            r["matched_title"],
            r["similarity"],
            r["year"] or "",
            r["authors"],
            r["venue"],
            r["volume"],
            r["pages"],
            r["pub_type"],
            r["url"],
            r["google_scholar_link"],
            r["apa_citation"],
        ])

    text = buf.getvalue()
    if filepath:
        with open(filepath, "w", encoding="utf-8-sig", newline="") as f:
            f.write(text)
        print(f"\n已輸出 CSV 報告：{filepath}")
    return text


def output_markdown(results, filepath=None):
    """輸出 Markdown 表格格式報告。"""
    lines = []
    lines.append("# 引用驗證報告")
    lines.append("")
    lines.append(f"**產生時間**：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("")

    # 統計摘要
    total = len(results)
    verified = sum(1 for r in results if r["status"] == "已驗證")
    possible = sum(1 for r in results if r["status"] == "可能匹配")
    not_matched = total - verified - possible

    lines.append("## 摘要統計")
    lines.append("")
    lines.append(f"| 項目 | 數量 |")
    lines.append(f"|------|------|")
    lines.append(f"| 總計 | {total} |")
    lines.append(f"| 已驗證 | {verified} |")
    lines.append(f"| 可能匹配 | {possible} |")
    lines.append(f"| 不匹配/查無結果 | {not_matched} |")
    lines.append("")

    # 詳細結果
    lines.append("## 詳細結果")
    lines.append("")

    for i, r in enumerate(results, 1):
        status_icon = {"已驗證": "✅", "可能匹配": "⚠️",
                       "不匹配": "❌", "查無結果": "❌",
                       "未找到": "❌"}.get(r["status"], "❓")

        lines.append(f"### {i}. {r['query_title']}")
        lines.append("")
        lines.append(f"- **狀態**：{status_icon} {r['status']}")
        lines.append(f"- **相似度**：{r['similarity']}")
        if r["matched_title"]:
            lines.append(f"- **配對標題**：{r['matched_title']}")
        if r["year"]:
            lines.append(f"- **年份**：{r['year']}")
        if r["authors"]:
            lines.append(f"- **作者**：{r['authors']}")
        if r["venue"]:
            lines.append(f"- **期刊/會議**：{r['venue']}")
        if r["volume"]:
            lines.append(f"- **卷數**：{r['volume']}")
        if r["pages"]:
            lines.append(f"- **頁碼**：{r['pages']}")
        if r["pub_type"]:
            lines.append(f"- **出版類型**：{r['pub_type']}")
        if r["url"]:
            lines.append(f"- **來源網址**：{r['url']}")
        if r["google_scholar_link"]:
            lines.append(f"- **Google Scholar**：{r['google_scholar_link']}")
        if r["apa_citation"]:
            lines.append(f"- **APA 引用**：{r['apa_citation']}")
        lines.append("")

    text = "\n".join(lines)
    if filepath:
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"\n已輸出 Markdown 報告：{filepath}")
    return text


# ============================================================
# CLI 主程式
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="引用驗證工具 — 透過 Crossref API 驗證學術引用",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
範例：
  python verify_citations.py --input refs.txt --output report.md
  python verify_citations.py --input refs.json --output report.json --threshold 0.7
  python verify_citations.py --input refs.txt --output report.csv --threshold 0.5

作者：阿亮老師・3A科技研究社
        """
    )
    parser.add_argument(
        "--input", "-i", required=True,
        help="輸入檔案路徑（.txt 或 .json）"
    )
    parser.add_argument(
        "--output", "-o", required=True,
        help="輸出檔案路徑（副檔名決定格式：.json / .csv / .md）"
    )
    parser.add_argument(
        "--threshold", "-t", type=float, default=0.6,
        help="相似度門檻值（預設 0.6）"
    )
    parser.add_argument(
        "--format", "-f", choices=["json", "csv", "md"],
        default=None,
        help="輸出格式（若未指定，由輸出檔案副檔名決定）"
    )
    parser.add_argument(
        "--resume", action="store_true",
        help="續跑模式：自動跳過已查核的項目，保留已有結果（需搭配 JSON 輸出）"
    )

    args = parser.parse_args()

    # 決定輸出格式
    if args.format:
        fmt = args.format
    else:
        ext = os.path.splitext(args.output)[1].lower()
        fmt_map = {".json": "json", ".csv": "csv", ".md": "md", ".markdown": "md"}
        fmt = fmt_map.get(ext, "json")

    # 載入輸入
    print(f"載入輸入檔案：{args.input}")
    try:
        titles = load_input(args.input)
    except Exception as e:
        print(f"錯誤：無法載入輸入檔案 — {e}", file=sys.stderr)
        sys.exit(1)

    if not titles:
        print("警告：輸入檔案中沒有找到任何標題。", file=sys.stderr)
        sys.exit(0)

    print(f"共 {len(titles)} 筆標題待驗證（相似度門檻：{args.threshold}）")
    print("=" * 60)

    # 批次驗證（支援續跑）
    resume_file = None
    if args.resume:
        resume_file = os.path.splitext(args.output)[0] + ".json"
        print(f"續跑模式：從 {resume_file} 載入已有結果")
    results = verify_batch(titles, threshold=args.threshold, resume_file=resume_file)

    print("=" * 60)

    # 統計
    verified = sum(1 for r in results if r["status"] == "已驗證")
    possible = sum(1 for r in results if r["status"] == "可能匹配")
    print(f"\n驗證完成：{verified} 已驗證 / {possible} 可能匹配 / "
          f"{len(results) - verified - possible} 不匹配或查無結果")

    # 輸出
    if fmt == "json":
        output_json(results, args.output)
    elif fmt == "csv":
        output_csv(results, args.output)
    elif fmt == "md":
        output_markdown(results, args.output)

    # 同時輸出 JSON（便於其他工具讀取）
    if fmt != "json":
        json_path = os.path.splitext(args.output)[0] + ".json"
        output_json(results, json_path)


if __name__ == "__main__":
    main()
